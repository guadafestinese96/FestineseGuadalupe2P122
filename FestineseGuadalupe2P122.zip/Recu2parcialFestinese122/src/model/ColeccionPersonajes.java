package model;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;
import persistence.PersistenciaPersonajes;

public class ColeccionPersonajes {

    private List<Personaje> lista = new ArrayList<>();

    public void agregar(Personaje p) {
        lista.add(p);
    }

    public void ordenar(Comparator<Personaje> comp) {
        if (comp != null) {
            lista.sort(comp);
        } else {
            lista.sort(Comparator.naturalOrder());
        }
    }

    public List<Personaje> filtrar(Predicate<Personaje> criterio) {
        List<Personaje> listaFiltrada = new ArrayList<>();
        for (Personaje p : lista) {
            if (criterio.test(p)) {
                listaFiltrada.add(p);
            }
        }
        return listaFiltrada;
    }

    public void paraCadaElemento(Consumer<Personaje> c) {
        lista.forEach(c);
    }


    public void guardarEnArchivo(String path) throws IOException {
        PersistenciaPersonajes.serializarPersonajes(lista, path);
    }

    public void cargarDesdeArchivo(String path) throws IOException, ClassNotFoundException {
        lista = PersistenciaPersonajes.deserializarPersonajes(path);
    }

    public void guardarEnCSV(String path) throws IOException {
        PersistenciaPersonajes.guardarPersonajesCSV(lista, path);
    }

    public void cargarDesdeCSV(String path) throws IOException {
        lista = PersistenciaPersonajes.cargarPersonajesCSV(path);
    }
}
