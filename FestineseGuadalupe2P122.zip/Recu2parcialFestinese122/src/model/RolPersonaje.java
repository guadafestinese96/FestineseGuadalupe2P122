
package model;

public enum RolPersonaje {
   TANQUE,
   MAGO,
   ARQUERO,
   ASESINO,
   SANADOR,
   INGENIERO
}
