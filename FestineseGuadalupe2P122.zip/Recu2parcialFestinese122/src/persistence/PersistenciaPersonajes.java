package persistence;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import model.Personaje;

public interface PersistenciaPersonajes {

    public static void serializarPersonajes(List<Personaje> lista, String path) {
        try (ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(path))) {
            salida.writeObject(lista);        
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    public static List<Personaje> deserializarPersonajes(String path) { 
       List<Personaje> toReturn = null;
        try (ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(path))) {
            toReturn = (List<Personaje>) entrada.readObject();
        } catch (IOException | ClassNotFoundException ex) {
            System.out.println(ex.getMessage());
        }
        return toReturn;
    }

    public static void guardarPersonajesCSV(List<Personaje> lista, String path) {
        try (BufferedWriter escritor = new BufferedWriter(new FileWriter(path))) {
            escritor.write(Personaje.getHeaderCSV());
            escritor.newLine();

            for (Personaje p : lista) {
                escritor.write(p.toCSV());
                escritor.newLine();
            }

        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    public static List<Personaje> cargarPersonajesCSV(String path) {
        List<Personaje> lista = new ArrayList<>();
        try (BufferedReader lector = new BufferedReader(new FileReader(path))) {
            lector.readLine();
            String linea;
            while ((linea = lector.readLine()) != null) {
                lista.add(Personaje.fromCSV(linea));
            }

        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }

        return lista;
    }
}
